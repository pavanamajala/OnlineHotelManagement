import React from 'react'

export default function MainRoom() {
  return (
    <div>
      <h1 >
         <a href="/room/viewall">Viewall</a>
         
    </h1>
    </div>
  )
}
