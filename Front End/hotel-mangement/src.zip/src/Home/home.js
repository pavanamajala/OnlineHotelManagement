import { Formik, Form, Field, ErrorMessage } from "formik";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import download from '../Images/welcome.png'
import axios from 'axios';


function Home() {

  let navigate=useNavigate();

  let handleSubmit = async(values) => {
    const result=await axios.post(`http://localhost:8083/user/sign/validate/${values.email}/${values.password}`);
    
    console.log(result);
    if(result.data==='owner'){
      navigate("/owner")
    } else if(result.data ==='manager'){
      navigate('/manager')
    } else if(result.data ==='receptionist'){
      navigate("/receptionist")
    }else if(result.data ==='unmatched'){
       alert("Username and Password didn't match")
        console.log("Username and Password didn't match");
    }
  };

  let handleValidation = (values) => {
    const errors = {};
    if (!values.email ) {
      errors.email = " Username cannot be empty";
    }
    if (!values.password) {
      errors.password = "Password cannot be empty";
    } else if (values.password.length < 8) {
      errors.password = "Password should have minimum 8 characters";
      errors.login= "Username and Password didn't match"
    } 
    return errors;

  };

  return (
    
        <div className="container pavlog">
          <div className='pavhometxt'><img className='pavhomeimg' src={download}></img>
          </div>
            <div className="row pavhomelogin">
               <div className="col-md-4 offset-md-8 border rounded p-4 mt-5 shadow pavhombg">
                  <Formik
                    initialValues={{ email: "", password: "" }}
                    onSubmit={(e) => handleSubmit(e)}
                    validate={(e) => handleValidation(e)}
                  >
                    {(props) => (
                    <Form className="form">
                        <h2 className="text-center m-4"><u>Login</u></h2>
                        <form>
                            <div className="mb-3 ">
                                <label class="form-label" for="form1Example1"><b> Username</b></label>
                                   <Field type="email" name="email"  className="form-control"/>
              
                                      <ErrorMessage name="email">
                                          {(error) => <p className="validatered">{error}</p>}
                                      </ErrorMessage>
                            </div>

                            <div class="mb-3">
                                 <label class="form-label" for="form1Example2"><b> Password</b></label>
                                     <br/>
                                       <Field type="password" name="password" className="form-control"/>
                                          <ErrorMessage name="password">
                                            {(error) => <p className="validatered">{error}</p>}
                                          </ErrorMessage>
                             </div>
                                  
                         </form><br></br>
                         
                        <button class="btn btn-primary pavhomebut" type="submit">Login<i class="fa fa-plane ms-3"></i>
                        </button>
                     </Form>
                    )}
                  </Formik>
                </div>
              </div> 
          </div>
          
  );
}
export default Home;





// import axios from 'axios';
// import React, { useState } from 'react'
// import { Link, useNavigate } from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.css';
// import download from '../Images/welcome.png'

// export default function Home() {


//   let handleSubmit = (values) => {
//     console.log(values);
//   };
//   let handleValidation = (values) => {
//     const errors = {};
//     if (!values.email) {
//       errors.email = " Email cannot be empty";
//     }
//     if (!values.password) {
//       errors.password = "Password cannot be empty";
//     } else if (values.password.length < 8) {
//       errors.password = "Password should have minimum 8 characters";
//     }
//     return errors;
//   };

//   return (

//     <div className="container ">
//       <div className='pavhometxt'><img className='pavhomeimg' src={download}></img></div>
//       <div className="row pavhomelogin">
//         <div className="col-md-4 offset-md-8 border rounded p-4 mt-5 shadow pavhombg">
//           <Formik>
//           <h2 className="text-center m-4"><u>Login</u></h2>

//           <form onSubmit={handleValidation()}>
//                 <div className="mb-3 ">
//                         <label htmlFor="user" className="form-label">
//                             <b> Username</b>
//                         </label>
//                         <input
//                             type={"text"}
//                             className="form-control"
//                             placeholder="Enter username"
//                             name="username"
//                             //value={employeeId}
//                            // onChange={(e)=>onInputChange(e)}
//                             id="user"
//                         />
//                         <p id="usernametext"></p>
//                     </div>
//                     <div className="mb-3">
//                         <label htmlFor="pass" className="form-label">
//                             <b> Password</b>
//                         </label>
//                         <input
//                             type={"text"}
//                             className="form-control"
//                             placeholder="Enter password"
//                             name="employeeName"
//                             //value={employeeName}
//                            // onChange={(e)=>onInputChange(e)}
//                             id="pass"
//                         />
//                     </div>
//                     <br></br>
//                   <Link to="./owner"> <button type="submit" className="btn btn-primary pavhomebut" >Submit</button></Link> 
//                  </form>
//                  </Formik>
//         </div>
//       </div>
//     </div>
//   )
// }


