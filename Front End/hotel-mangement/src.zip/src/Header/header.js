import React from 'react'

export default function Header() {
  return (
    
    <nav class="navbar navbar-dark pavhead bg-secondary">
  <div class="container-md">
  
  <a class="navbar-brand text-left" href="/">Home</a>
    <div class="navbar-brand text-centre">
 <b className='text-white'> HOTEL MANAGEMENT</b>
</div>
<div className='navbar-brand text-right'> About</div>
  </div>
</nav>

  )
}
