import "../CSS/main.css"
import React from 'react'

export default function Footer() {
  return (
    
    

    <div class="text-center  text-white pavfoot bg-secondary">CREATED BY PAVAN
    </div>
  


  )
}
