import React from 'react'
import { Link } from 'react-router-dom'

export default function MainReservation() {
  return (
    <div className="container">
    <h1 >
         <a href="/inventory/viewall">Viewall</a>
         
    </h1>
    </div>
  )
}
