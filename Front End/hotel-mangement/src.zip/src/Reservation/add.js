import axios from 'axios';
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

export default function AddReservation() {

    let navigate=useNavigate();

    const [user, setUser]=useState({
        reservationId: "",
        roomId:"",
        guestId:"",
        checkInDate: "",
        checkOutDate:"",
        noOfGuest:"",
        totalPrice:""
    });

    // function validateform(){  
    //     var id=document.getElementById("id"); 
    //     let text;
    //       if(id==null){
    //         alert("id can't be null")
    //       } else{
    //         onSubmit();
    //         // {(e)=>onSubmit(e)}
    //       }
    //  }  

     const{reservationId,roomId,guestId,checkInDate,checkOutDate,noOfGuest,totalPrice}=user

    const onInputChange=(e)=>{

        setUser({ ...user, [e.target.name]: e.target.value})

    };

    const onSubmit=async (e)=> {
        e.preventDefault();
        await axios.post("http://localhost:8085/reservation/add", user);
        navigate("/reservation/viewall")
    };

  return (

    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4"><u>Register Reservation</u></h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="../room/viewall" className="btn btn-success text-centre float-right" >
          View Rooms
        </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="../guest/viewall" className="btn btn-success float-centre" >
          View Guests
        </a><br></br><br></br>
          <form onSubmit={(e)=>onSubmit(e)}>
                <div className="mb-3">
                        <label htmlFor="Id" className="form-label">
                            <b>Reservation ID</b>
                        </label>
                        <input
                            type={"number"}
                            className="form-control"
                            placeholder="Enter Reservation ID"
                            name="reservationId"
                            value={reservationId}
                            onChange={(e)=>onInputChange(e)}
                            id="reserve-id"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Id" className="form-label">
                            <b>Room ID</b>
                        </label>
                        <input
                            type={"number"}
                            className="form-control"
                            placeholder="Enter Room ID"
                            name="roomId"
                            value={roomId}
                            onChange={(e)=>onInputChange(e)}
                            id="room-id"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Id" className="form-label">
                            <b>Guest ID</b>
                        </label>
                        <input
                            type={"number"}
                            className="form-control"
                            placeholder="Enter Guest ID"
                            name="guestId"
                            value={guestId}
                            onChange={(e)=>onInputChange(e)}
                            id="guest-id"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="checkIn" className="form-label">
                            <b> check In Date</b>
                        </label>
                        <input
                            type={"text"}
                            className="form-control"
                            placeholder="Enter Check In Date"
                            name="checkInDate"
                            value={checkInDate}
                            onChange={(e)=>onInputChange(e)}
                            id="checkIn"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="checkOut" className="form-label">
                            <b> check Out Date</b>
                        </label>
                        <input
                            type={"text"}
                            className="form-control"
                            placeholder="Enter Check Out Date"
                            name="checkOutDate"
                            value={checkOutDate}
                            onChange={(e)=>onInputChange(e)}
                            id="checkIn"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="num" className="form-label">
                            <b>No Of Guests</b>
                        </label>
                        <input
                            type={"number"}
                            className="form-control"
                            placeholder="Enter Number of Guests"
                            name="noOfGuest"
                            value={noOfGuest}
                            onChange={(e)=>onInputChange(e)}
                            id="num"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="price" className="form-label">
                            <b>Total Price</b>
                        </label>
                        <input
                            type={"number"}
                            className="form-control"
                            placeholder="Enter total price"
                            name="totalPrice"
                            value={totalPrice}
                            onChange={(e)=>onInputChange(e)}
                            id="price"
                        />
                    </div>
                    <button type="submit" className="btn btn-outline-primary" >Submit</button>
                    <Link to="/reservation/viewall" className="btn btn-outline-danger mx-2">Cancel</Link>
                 </form>
        </div>
      </div>
    </div>
  )
}
