import React from 'react'
import { Link } from 'react-router-dom'

export default function MainGuest() {
  return (
    <div className="container">
    <h1 >
         <a href="/guest/viewall">Viewall</a>
         
    </h1>
    </div>
  )
}
